from sqlalchemy import Column, Integer, String, Date, ForeignKey, Boolean, Table, Text, Enum
from sqlalchemy.orm import relationship
import enum
from app.database import Base


# Role Enum
class RoleEnum(str, enum.Enum):
    admin = "admin"
    professor = "professor"
    student = "student"


# Association Table for Assignments and Students (many-to-many)
assignment_students = Table(
    'assignment_students',
    Base.metadata,
    Column('student_id', Integer, ForeignKey('students.id'), primary_key=True),
    Column('assignment_id', Integer, ForeignKey('assignments.id'), primary_key=True)
)


class Student(Base):
    __tablename__ = "students"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String, index=True)
    email = Column(String, unique=True, index=True)

    attendance = relationship("Attendance", back_populates="student")
    marks = relationship("Mark", back_populates="student", cascade="all, delete-orphan")
    user = relationship("User", back_populates="student", uselist=False)
    assignments = relationship("Assignment", secondary=assignment_students, back_populates="students")
    submissions = relationship("Submission", back_populates="student")


class Attendance(Base):
    __tablename__ = "attendance"
    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    date = Column(Date, nullable=False)
    status = Column(String, nullable=False)  # e.g. "Present" or "Absent"

    student = relationship("Student", back_populates="attendance")


class Mark(Base):
    __tablename__ = "marks"
    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    assignment_id = Column(Integer, ForeignKey("assignments.id"), nullable=True)  # optional FK to assignment
    score = Column(Integer, nullable=False)
    subject = Column(String, nullable=False)  # customized subject name

    student = relationship("Student", back_populates="marks")
    assignment = relationship("Assignment", back_populates="marks")


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    username = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    role = Column(Enum(RoleEnum), default=RoleEnum.student)

    student_id = Column(Integer, ForeignKey("students.id"), nullable=True)
    student = relationship("Student", back_populates="user")

    assignments = relationship("Assignment", back_populates="professor")


class Assignment(Base):
    __tablename__ = "assignments"

    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String)
    description = Column(String, nullable=True)

    professor_id = Column(Integer, ForeignKey("users.id"))
    professor = relationship("User", back_populates="assignments")
    marks = relationship("Mark", back_populates="assignment")

    students = relationship("Student", secondary=assignment_students, back_populates="assignments")
    submissions = relationship("Submission", back_populates="assignment")


class Submission(Base):
    __tablename__ = "submissions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    assignment_id = Column(Integer, ForeignKey("assignments.id"))
    student_id = Column(Integer, ForeignKey("students.id"))

    file_path = Column(String, nullable=True)
    content = Column(Text, nullable=True)
    submitted = Column(Boolean, default=False)

    assignment = relationship("Assignment", back_populates="submissions")
    student = relationship("Student", back_populates="submissions")
