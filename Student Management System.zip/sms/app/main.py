from fastapi import FastAPI, Depends, Request, Form, HTTPException, Response, Cookie, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse, FileResponse
from fastapi import Path
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from passlib.context import CryptContext
from datetime import date
from datetime import datetime
import shutil
import os
import io
import csv
from fastapi.responses import StreamingResponse
from sqlalchemy.sql import func
from sqlalchemy.orm import Session
from flask_login import logout_user
from flask import flash, redirect, url_for






# Define a global upload directory
UPLOAD_DIR = "uploads"
COURSE_UPLOAD_DIR = os.path.join(UPLOAD_DIR, "course_materials")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(COURSE_UPLOAD_DIR, exist_ok=True)

from app import models
from app.database import SessionLocal, engine

# -------------------------
# CONFIG
# -------------------------
SECRET_KEY = "your_super_secret_key_here"
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# -------------------------
# CREATE DATABASE TABLES
# -------------------------
models.Base.metadata.create_all(bind=engine)

# -------------------------
# INITIAL USERS
# -------------------------
def create_user_if_not_exists(db: Session, username, email, password, role):
    if not db.query(models.User).filter(models.User.username == username).first():
        print(f"[DEBUG] Password being hashed: {password} (length: {len(password)})")
        user = models.User(
            username=username,
            email=email,
            hashed_password=pwd_context.hash(password),
            role=role
        )
        db.add(user)
        db.commit()
        db.refresh(user)
    return db

db = SessionLocal()
create_user_if_not_exists(db, "admin", "admin@example.com", "admin123", "admin")
create_user_if_not_exists(db, "prof1", "prof1@example.com", "prof123", "professor")
create_user_if_not_exists(db, "student1", "student1@example.com", "stud123", "student")
db.close()

# -------------------------
# FASTAPI INIT
# -------------------------
app = FastAPI()
templates = Jinja2Templates(directory="templates")

# -------------------------
# DEPENDENCIES
# -------------------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

# -------------------------
# CURRENT USER
# -------------------------
def get_current_user(user_id: int = Cookie(None), db: Session = Depends(get_db)):
    if not user_id:
        raise HTTPException(status_code=401, detail="Not authenticated")
    user = db.query(models.User).filter(models.User.id == int(user_id)).first()
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user

# -------------------------
# ROLE DEPENDENCIES
# -------------------------
def admin_required(user: models.User = Depends(get_current_user)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access only")
    return user

def professor_required(user: models.User = Depends(get_current_user)):
    if user.role != "professor":
        raise HTTPException(status_code=403, detail="Professor access only")
    return user

def student_required(user: models.User = Depends(get_current_user)):
    if user.role != "student":
        raise HTTPException(status_code=403, detail="Student access only")
    return user

# -------------------------
# LOGIN / LOGOUT
# -------------------------
@app.get("/login", response_class=HTMLResponse)
def login_get(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
def login_post(request: Request, response: Response,
               username: str = Form(...), password: str = Form(...),
               db: Session = Depends(get_db)):

    user = db.query(models.User).filter(models.User.username == username).first()
    if not user or not verify_password(password, user.hashed_password):
        return templates.TemplateResponse("login.html", {"request": request, "error": "Invalid credentials"})

    response = RedirectResponse(url=f"/{user.role.value}/dashboard", status_code=303)
    response.set_cookie(key="user_id", value=str(user.id), httponly=True)
    return response

@app.get("/logout")
def logout():
    response = RedirectResponse(url="/login", status_code=303)
    response.delete_cookie(key="user_id")
    return response

# -------------------------
# DASHBOARDS
# -------------------------
@app.get("/admin/dashboard", response_class=HTMLResponse)
def admin_dashboard(request: Request, db: Session = Depends(get_db),
                    current_user: models.User = Depends(admin_required)):
    students = db.query(models.Student).all()
    professors = db.query(models.User).filter(models.User.role == "professor").all()
    admins = db.query(models.User).filter(models.User.role == "admin").all()
    return templates.TemplateResponse(
        "admin_dashboard.html",
        {"request": request, "students": students, "professors": professors, "admins": admins, "current_user": current_user}
    )

@app.get("/professor/dashboard", response_class=HTMLResponse)
def professor_dashboard(request: Request, db: Session = Depends(get_db),
                        current_user: models.User = Depends(professor_required)):
    students = db.query(models.Student).all()
    assignments = db.query(models.Assignment).filter(models.Assignment.professor_id == current_user.id).all()
    return templates.TemplateResponse(
        "professor_dashboard.html",
        {"request": request, "students": students, "assignments": assignments, "current_user": current_user}
    )

@app.get("/student/dashboard", response_class=HTMLResponse)
def student_dashboard(request: Request, db: Session = Depends(get_db),
                      current_user: models.User = Depends(student_required)):
    student = db.query(models.Student).filter(models.Student.id == current_user.student_id).first()
    assignments = student.assignments if student else []
    return templates.TemplateResponse(
        "student_dashboard.html",
        {"request": request, "student": student, "assignments": assignments, "current_user": current_user}
    )

@app.post('/logout')
async def logout(request: Request):
    response = RedirectResponse(url='/login', status_code=303)
    # Clear cookie here - example if session cookie named 'session'
    response.delete_cookie('session')
    return response

# -------------------------
# DOWNLOAD FILE ROUTE
# -------------------------
@app.get("/download/{filename:path}", name="download_file")
def download_file(filename: str = Path(...)):
    # Sanitize filename so no relative path traversal
    safe_filename = os.path.basename(filename)
    file_path = os.path.join(UPLOAD_DIR, safe_filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(path=file_path, filename=safe_filename)
# -------------------------
# STUDENT CRUD (Admin Only)
# -------------------------
@app.get("/add-student", response_class=HTMLResponse)
def show_add_student_form(request: Request, student_id: int = None,
                          db: Session = Depends(get_db),
                          current_user: models.User = Depends(admin_required)):
    student = None
    if student_id:
        student = db.query(models.Student).filter(models.Student.id == student_id).first()
    return templates.TemplateResponse("add_student.html", {"request": request, "student": student})

@app.post("/add-student")
def add_student_via_form(name: str = Form(...), email: str = Form(...), password: str = Form(...),
                         student_id: int = Form(None),
                         db: Session = Depends(get_db),
                         current_user: models.User = Depends(admin_required)):
    if not student_id:
        existing_user = db.query(models.User).filter(models.User.email == email).first()
        if existing_user:
            raise HTTPException(status_code=400, detail="Email already registered")

    if student_id:
        student = db.query(models.Student).filter(models.Student.id == student_id).first()
        student.name = name
        student.email = email
        user = db.query(models.User).filter(models.User.student_id == student_id).first()
        if user:
            user.hashed_password = pwd_context.hash(password)
    else:
        student = models.Student(name=name, email=email)
        db.add(student)
        db.commit()
        db.refresh(student)
        user = models.User(
            username=name.lower().replace(" ", "")[:10],
            email=email,
            hashed_password=pwd_context.hash(password),
            role="student",
            student_id=student.id
        )
        db.add(user)
    db.commit()
    return RedirectResponse(url="/admin/dashboard", status_code=303)

@app.get("/delete-student/{student_id}")
def delete_student(student_id: int, db: Session = Depends(get_db),
                   current_user: models.User = Depends(admin_required)):
    student = db.query(models.Student).filter(models.Student.id == student_id).first()
    if student:
        db.delete(student)
        db.commit()
    return RedirectResponse(url="/admin/dashboard", status_code=303)

# -------------------------
# PROFESSOR CRUD (Admin Only)
# -------------------------
@app.get("/add-professor", response_class=HTMLResponse)
def show_add_professor_form(request: Request, professor_id: int = None,
                            db: Session = Depends(get_db),
                            current_user: models.User = Depends(admin_required)):
    professor = None
    if professor_id:
        professor = db.query(models.User).filter(models.User.id == professor_id, models.User.role == "professor").first()
    return templates.TemplateResponse("add_professor.html", {"request": request, "professor": professor})
    

@app.post("/add-professor")
def add_professor_via_form(username: str = Form(...),
                           email: str = Form(...),
                           password: str = Form(...),
                           professor_id: int = Form(None),
                           db: Session = Depends(get_db),
                           current_user: models.User = Depends(admin_required)):
    
    if not professor_id:
        existing_user = db.query(models.User).filter(models.User.email == email).first()
        if existing_user:
            raise HTTPException(status_code=400, detail="Email already registered")

    if professor_id:
        prof = db.query(models.User).filter(models.User.id == professor_id, models.User.role == "professor").first()
        prof.username = username
        prof.email = email
        prof.hashed_password = pwd_context.hash(password)
    else:
        prof = models.User(
            username=username,
            email=email,
            hashed_password=pwd_context.hash(password),
            role="professor"
        )
        db.add(prof)

    db.commit()
    return RedirectResponse(url="/admin/dashboard", status_code=303)

@app.get("/delete-professor/{professor_id}")
def delete_professor(professor_id: int, db: Session = Depends(get_db),
                     current_user: models.User = Depends(admin_required)):
    professor = db.query(models.User).filter(models.User.id == professor_id, models.User.role == "professor").first()
    if professor:
        db.delete(professor)
        db.commit()
    return RedirectResponse(url="/admin/dashboard", status_code=303)

# --------------------------
# ADD MARKS
#---------------------------

@app.get("/add-marks/{student_id}", response_class=HTMLResponse)
def add_marks_form(student_id: int, request: Request,
                   db: Session = Depends(get_db),
                   current_user: models.User = Depends(professor_required)):
    student = db.query(models.Student).get(student_id)
    assignments = db.query(models.Assignment).filter_by(professor_id=current_user.id).all()
    return templates.TemplateResponse("add_marks.html",
        {"request": request, "student": student, "assignments": assignments})

@app.post("/add-marks/{student_id}")
def add_marks(student_id: int,
              subject: str = Form(...),
              score: int = Form(...),
              db: Session = Depends(get_db),
              current_user: models.User = Depends(professor_required)):
    
    mark = models.Mark(student_id=student_id, subject=subject, score=score)
    db.add(mark)
    db.commit()
    return RedirectResponse(url="/professor/dashboard", status_code=303)

# -----------------------
# ADD ATTENDENCE
# -------------------------

@app.get("/add-attendance/{student_id}", response_class=HTMLResponse)
def attendance_form(student_id: int, request: Request,
                    db: Session = Depends(get_db),
                    current_user: models.User = Depends(professor_required)):
    student = db.query(models.Student).get(student_id)
    return templates.TemplateResponse("add_attendance.html", {
        "request": request, 
        "student": student,
        "date": date
    })

@app.post("/add-attendance/{student_id}")
def mark_attendance(student_id: int,
                    date: str = Form(...),  # format 'YYYY-MM-DD'
                    status: str = Form(...),
                    db: Session = Depends(get_db),
                    current_user: models.User = Depends(professor_required)):
    attendance_date = datetime.strptime(date, '%Y-%m-%d').date()
    att = models.Attendance(student_id=student_id, date=attendance_date, status=status)
    db.add(att)
    db.commit()
    return RedirectResponse(url="/professor/dashboard", status_code=303)


# -------------------------
# ASSIGNMENTS (Professor Only)
# -------------------------
@app.get("/add-assignment", response_class=HTMLResponse)
def show_add_assignment_form(request: Request, db: Session = Depends(get_db),
                             current_user: models.User = Depends(professor_required)):
    students = db.query(models.Student).all()
    return templates.TemplateResponse("add_assignment.html", {"request": request, "students": students})

@app.post("/add-assignment")
def add_assignment(title: str = Form(...), description: str = Form(...),
                   file: UploadFile = File(None),
                   student_ids: list[int] = Form([]),
                   db: Session = Depends(get_db),
                   current_user: models.User = Depends(professor_required)):
    assignment = models.Assignment(title=title, description=description, professor_id=current_user.id)

    # Save professor uploaded file
    if file:
        file_path = os.path.join(UPLOAD_DIR, f"assignment_{file.filename}")
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        assignment.file_path = file_path

    db.add(assignment)
    db.commit()
    db.refresh(assignment)

    for sid in student_ids:
        student = db.query(models.Student).filter(models.Student.id == sid).first()
        if student:
            assignment.students.append(student)
    db.commit()
    return RedirectResponse(url="/professor/dashboard", status_code=303)


@app.post("/delete-assignment/{assignment_id}")
def delete_assignment(assignment_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    # Ensure the logged-in professor owns this assignment
    assignment = db.query(models.Assignment).filter(models.Assignment.id == assignment_id,
                                                    models.Assignment.professor_id == current_user.id).first()
    if not assignment:
        raise HTTPException(status_code=404, detail="Assignment not found or access denied")
    
    # Delete the assignment and any related submissions
    db.delete(assignment)
    db.commit()
    return RedirectResponse(url="/professor/dashboard", status_code=303)


# -------------------------
# STUDENT ASSIGNMENTS
# -------------------------
@app.get("/submit-assignment/{assignment_id}", response_class=HTMLResponse)
def show_submit_assignment_form(assignment_id: int, request: Request,
                                db: Session = Depends(get_db),
                                current_user: models.User = Depends(student_required)):
    student = db.query(models.Student).filter(models.Student.id == current_user.student_id).first()
    assignment = db.query(models.Assignment).filter(models.Assignment.id == assignment_id).first()
    return templates.TemplateResponse("submit_assignment.html",
                                      {"request": request, "student": student, "assignment": assignment})

@app.post("/submit-assignment/{assignment_id}")
def submit_assignment(assignment_id: int,
                      submission_text: str = Form(None),
                      file: UploadFile = File(None),
                      db: Session = Depends(get_db),
                      current_user: models.User = Depends(student_required)):

    student = db.query(models.Student).filter(models.Student.id == current_user.student_id).first()
    assignment = db.query(models.Assignment).filter(models.Assignment.id == assignment_id).first()
    if not student or not assignment:
        raise HTTPException(status_code=404, detail="Student or Assignment not found")

    submission = db.query(models.Submission).filter(
        models.Submission.student_id == student.id,
        models.Submission.assignment_id == assignment.id
    ).first()

    file_path = None
    if file:
        file_path = os.path.join(UPLOAD_DIR, f"submission_{student.id}_{assignment.id}_{file.filename}")
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

    if not submission:
        submission = models.Submission(
            student_id=student.id,
            assignment_id=assignment.id,
            content=submission_text,
            file_path=file_path,
            submitted=True
        )
        db.add(submission)
    else:
        submission.content = submission_text
        submission.file_path = file_path or submission.file_path
        submission.submitted = True

    db.commit()
    return RedirectResponse(url="/student/dashboard", status_code=303)

# -------------------------
# ADMIN CRUD (Admin Only)
# -------------------------
@app.get("/add-admin", response_class=HTMLResponse)
def show_add_admin_form(request: Request, admin_id: int = None,
                        db: Session = Depends(get_db),
                        current_user: models.User = Depends(admin_required)):
    admin = None
    if admin_id:
        admin = db.query(models.User).filter(models.User.id == admin_id, models.User.role == "admin").first()
    return templates.TemplateResponse("add_admin.html", {"request": request, "admin": admin})

@app.post("/add-admin")
def add_admin_via_form(username: str = Form(...),
                       email: str = Form(...),
                       password: str = Form(...),
                       admin_id: int = Form(None),
                       db: Session = Depends(get_db),
                       current_user: models.User = Depends(admin_required)):
    
    if not admin_id:
        existing_user = db.query(models.User).filter(models.User.email == email).first()
        if existing_user:
            raise HTTPException(status_code=400, detail="Email already registered")

    if admin_id:
        admin = db.query(models.User).filter(models.User.id == admin_id, models.User.role == "admin").first()
        admin.username = username
        admin.email = email
        admin.hashed_password = pwd_context.hash(password)
    else:
        admin = models.User(
            username=username,
            email=email,
            hashed_password=pwd_context.hash(password),
            role="admin"
        )
        db.add(admin)

    db.commit()
    return RedirectResponse(url="/admin/dashboard", status_code=303)

# -------------------------
# DELETE ADMIN (Admin Only)
# -------------------------
@app.get("/delete-admin/{admin_id}")
def delete_admin(admin_id: int,
                 db: Session = Depends(get_db),
                 current_user: models.User = Depends(admin_required)):
    admin = db.query(models.User).filter(models.User.id == admin_id, models.User.role == "admin").first()
    if admin:
        db.delete(admin)
        db.commit()
    return RedirectResponse(url="/admin/dashboard", status_code=303)

# -------------------------------------------------
# EXPORT
# -------------------------------------------------

@app.get("/student/{student_id}/export")
def export_student_report(student_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(student_required)):
    if current_user.student_id != student_id:
        raise HTTPException(status_code=403, detail="Unauthorized")

    marks = db.query(models.Mark).filter(models.Mark.student_id == student_id).all()
    attendance = db.query(models.Attendance).filter(models.Attendance.student_id == student_id).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Subject", "Score"])
    for mark in marks:
        writer.writerow([mark.subject, mark.score])
    writer.writerow([])
    writer.writerow(["Date", "Status"])
    for att in attendance:
        writer.writerow([att.date, att.status])
    output.seek(0)

    headers = {"Content-Disposition": f"attachment;filename=student_{student_id}_report.csv"}
    return StreamingResponse(iter([output.getvalue()]), media_type="text/csv", headers=headers)


@app.get("/professor/{professor_id}/export/{student_id}")
def export_professor_student_report(professor_id: int, student_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(professor_required)):
    if current_user.id != professor_id:
        raise HTTPException(status_code=403, detail="Unauthorized")

    # Verify student is assigned to professor's assignments if needed

    marks = db.query(models.Mark).filter(models.Mark.student_id == student_id).all()
    attendance = db.query(models.Attendance).filter(models.Attendance.student_id == student_id).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Subject", "Score"])
    for mark in marks:
        writer.writerow([mark.subject, mark.score])
    writer.writerow([])
    writer.writerow(["Date", "Status"])
    for att in attendance:
        writer.writerow([att.date, att.status])
    output.seek(0)

    headers = {"Content-Disposition": f"attachment;filename=professor_{professor_id}_student_{student_id}_report.csv"}
    return StreamingResponse(iter([output.getvalue()]), media_type="text/csv", headers=headers)


@app.get("/admin/export/{student_id}")
def export_admin_student_report(student_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(admin_required)):
    marks = db.query(models.Mark).filter(models.Mark.student_id == student_id).all()
    attendance = db.query(models.Attendance).filter(models.Attendance.student_id == student_id).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Subject", "Score"])
    for mark in marks:
        writer.writerow([mark.subject, mark.score])
    writer.writerow([])
    writer.writerow(["Date", "Status"])
    for att in attendance:
        writer.writerow([att.date, att.status])
    output.seek(0)

    headers = {"Content-Disposition": f"attachment;filename=admin_student_{student_id}_report.csv"}
    return StreamingResponse(iter([output.getvalue()]), media_type="text/csv", headers=headers)

