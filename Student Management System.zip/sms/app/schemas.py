from pydantic import BaseModel
from typing import List, Optional
from datetime import date
from enum import Enum

# ------------------------------
# Attendance Schemas
# ------------------------------
class AttendanceBase(BaseModel):
    date: date
    status: str

class AttendanceCreate(AttendanceBase):
    pass

class Attendance(AttendanceBase):
    id: int
    class Config:
        orm_mode = True


# ------------------------------
# Mark Schemas
# ------------------------------
class MarkBase(BaseModel):
    subject: str
    score: float

class MarkCreate(MarkBase):
    pass

class Mark(MarkBase):
    id: int
    class Config:
        orm_mode = True


# ------------------------------
# Submission Schemas
# ------------------------------
class SubmissionBase(BaseModel):
    submitted: bool = False
    file_path: Optional[str] = None   # uploaded file location
    feedback: Optional[str] = None    # professor feedback

class SubmissionCreate(BaseModel):
    assignment_id: int
    student_id: int
    submitted: bool = True
    file_path: Optional[str] = None

class Submission(SubmissionBase):
    id: int
    assignment_id: int
    student_id: int

    class Config:
        orm_mode = True


# ------------------------------
# Assignment Schemas
# ------------------------------
class AssignmentBase(BaseModel):
    title: str
    description: Optional[str] = None

class AssignmentCreate(AssignmentBase):
    professor_id: int
    student_ids: Optional[List[int]] = []

class Assignment(AssignmentBase):
    id: int
    professor_id: int
    submissions: List[Submission] = []
    students: List["Student"] = []

    class Config:
        orm_mode = True


# ------------------------------
# Student Schemas
# ------------------------------
class StudentBase(BaseModel):
    name: str
    email: str

class StudentCreate(StudentBase):
    pass

class Student(StudentBase):
    id: int
    attendance: List[Attendance] = []
    marks: List[Mark] = []
    assignments: List[Assignment] = []
    submissions: List[Submission] = []

    class Config:
        orm_mode = True


# ------------------------------
# User Schemas
# ------------------------------
class RoleEnum(str, Enum):
    admin = "admin"
    professor = "professor"
    student = "student"

class UserBase(BaseModel):
    username: str
    email: str
    role: RoleEnum

class UserCreate(UserBase):
    password: str
    student_id: Optional[int] = None
    professor_id: Optional[int] = None

class UserOut(BaseModel):
    id: int
    username: str
    email: str
    role: RoleEnum
    student_id: Optional[int] = None
    professor_id: Optional[int] = None

    class Config:
        orm_mode = True
